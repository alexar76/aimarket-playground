# AIMarket / Provider

Your service, a declared contract, a request-bound signature. Start locally, then check the public endpoint.

## 1. Create the provider

Install dependencies and generate your Ed25519 identity. Keep .aimarket/provider.key private and back it up; capability.json contains only the public key.

```sh
cd aimarket-provider
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[dev]' -r check-requirements.txt
.venv/bin/python configure_provider.py
```

## 2. Verify locally

Tests and the invoke profile run against your provider. Port 8080 must be free. check_local.py starts and stops the server, writes JSON to report.json and exits 0 only on a pass. The report is not signed by Hub.

```sh
.venv/bin/python -m pytest
.venv/bin/python validate_manifest.py
.venv/bin/python check_local.py > report.json
```

## 3. Expose the endpoint

The command starts a local server only. Deploy it behind an HTTPS ingress on port 443, preserve the private key, set invoke_url in capability.json and add access controls and rate limits. Then import the manifest into the public check. Never upload the private key.

```sh
.venv/bin/python agent.py
```

Passing aimarket-provider-invoke/1 checks one invocation and its signature, not the entire protocol. It does not publish the capability or test Hub receipts, payments, discovery, federation, freshness or load. Publication requires a separate decision and the selected Hub's admission and stake rules.

The archive contains a source snapshot from the generators or SDK, with SOURCES.json checksums. Dependencies install from package registries. No private keys are included. Commands use a macOS / Linux shell; on Windows use WSL. Extract the ZIP before running commands.

https://play.modelmarket.dev/start?role=provider&stack=python&lang=en
