# AIMarket / Fournisseur

Votre service, un contrat déclaré et une signature liée à la requête. Commencez localement, puis vérifiez le point de terminaison public.

## 1. Créer le fournisseur

Installez les dépendances et générez votre identité Ed25519. Gardez .aimarket/provider.key secret et sauvegardez-le ; capability.json ne contient que la clé publique.

```sh
cd aimarket-provider
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[dev]' -r check-requirements.txt
.venv/bin/python configure_provider.py
```

## 2. Vérifier localement

Les tests et le profil d’invocation vérifient votre fournisseur. Le port 8080 doit être libre. check_local.py démarre et arrête le serveur, écrit du JSON dans report.json et renvoie 0 uniquement en cas de succès. Hub ne signe pas le rapport.

```sh
.venv/bin/python -m pytest
.venv/bin/python validate_manifest.py
.venv/bin/python check_local.py > report.json
```

## 3. Exposer le point de terminaison

La commande démarre uniquement un serveur local. Déployez-le derrière HTTPS sur le port 443, conservez la clé privée, définissez invoke_url dans capability.json et ajoutez des contrôles d’accès et des limites de requêtes. Importez ensuite le manifeste dans la vérification publique. Ne téléversez jamais la clé privée.

```sh
.venv/bin/python agent.py
```

Réussir aimarket-provider-invoke/1 vérifie une invocation et sa signature, pas tout le protocole. Cela ne publie pas la capacité et ne teste ni reçus Hub, paiements, découverte, fédération, fraîcheur, ni charge. La publication nécessite une décision distincte et le respect des règles d’admission et de dépôt de garantie du Hub choisi.

L’archive contient un instantané des sources du générateur ou du SDK et leurs empreintes dans SOURCES.json. Les dépendances sont installées depuis les registres de paquets. Aucune clé privée n’est incluse. Les commandes sont destinées à macOS / Linux ; sous Windows, utilisez WSL. Décompressez le ZIP avant de les exécuter.

https://play.modelmarket.dev/start?role=provider&stack=python&lang=fr
