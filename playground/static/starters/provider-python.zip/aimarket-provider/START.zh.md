# AIMarket / 提供方

你的服务、声明的合约，以及与请求绑定的签名。先在本地运行，再检查公开端点。

## 1. 创建提供方

安装依赖并生成 Ed25519 身份密钥。妥善保密并备份 .aimarket/provider.key；capability.json 只包含公钥。

```sh
cd aimarket-provider
python3 -m venv .venv
.venv/bin/python -m pip install -e '.[dev]' -r check-requirements.txt
.venv/bin/python configure_provider.py
```

## 2. 本地验证

测试和调用配置文件将检查你的提供方。8080 端口必须空闲。check_local.py 启动并停止服务器，将 JSON 写入 report.json，仅在通过时返回 0。报告不由 Hub 签名。

```sh
.venv/bin/python -m pytest
.venv/bin/python validate_manifest.py
.venv/bin/python check_local.py > report.json
```

## 3. 开放公开端点

此命令仅启动本地服务器。请将其部署在 443 端口的 HTTPS 入口之后，保留私钥，在 capability.json 中设置 invoke_url，并添加访问控制和请求限流。然后将清单导入公开检查。切勿上传私钥。

```sh
.venv/bin/python agent.py
```

通过 aimarket-provider-invoke/1 仅验证一次调用及其签名，而非整个协议。这不会发布能力，也不测试 Hub 收据、支付、发现、联邦、新鲜性或负载。发布需要单独决定，并遵守所选 Hub 的发布准入和保证金规则。

压缩包包含生成器或 SDK 的源码快照，以及 SOURCES.json 中的校验和。依赖项从软件包注册表安装。不含私钥。命令适用于 macOS / Linux；Windows 请使用 WSL。运行前请解压 ZIP。

https://play.modelmarket.dev/start?role=provider&stack=python&lang=zh
