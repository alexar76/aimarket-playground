# AIMarket / 消费方

发现服务、在价格上限内调用并检查收据。初始项目使用 GAIA 天气测试输入。

## 1. 准备客户端

安装依赖并运行离线测试。项目已包含 SDK 快照：Python A2AClient 或 TypeScript market.run。发现服务不需要账户或钱包。

```sh
cd aimarket-consumer
npm install
npm test
```

## 2. 发现服务

在 modelmarket.dev 上进行只读发现。检查 GAIA 天气报价和 input.json。此示例仅允许来自 iot.modelmarket.dev 的 gaia.gateway / gaia.weather.read@v1。报价不可用时不会调用。

```sh
npm run discover
```

## 3. 调用一次

此命令授权一次真实调用，上限为 $0.01。没有凭据时会请求 Hub 的有限试用；如果本地设置了 AIMARKET_API_KEY，则可能扣除额度。支付被拒、超时或收据无效都会停止运行。没有自动充值或重试。

```sh
npm run invoke
```

Python 使用通过 TLS 获取的来源密钥在本地验证收据签名。TypeScript 请求 Hub 验证，并要求确认当前密钥。两者都不证明结果的事实准确性，也不独立固定身份。成功后保存 report.json。attempt.json 会阻止重复运行，包括响应丢失之后：在删除它并授权再次扣费之前，请先查明首次尝试的结果。

压缩包包含生成器或 SDK 的源码快照，以及 SOURCES.json 中的校验和。依赖项从软件包注册表安装。不含私钥。命令适用于 macOS / Linux；Windows 请使用 WSL。运行前请解压 ZIP。

https://play.modelmarket.dev/start?role=consumer&stack=typescript&lang=zh
