# AIMarket / Consommateur

Découvrez un service, invoquez-le avec un plafond de prix et inspectez le reçu. Le projet utilise l’exemple météo GAIA.

## 1. Préparer le client

Installez les dépendances et lancez les tests hors ligne. Un instantané du SDK est inclus : Python A2AClient ou TypeScript market.run. La découverte ne nécessite ni compte ni portefeuille.

```sh
cd aimarket-consumer
npm install
npm test
```

## 2. Découvrir le service

Découverte en lecture seule sur modelmarket.dev. Examinez l’offre météo GAIA et input.json. Seul gaia.gateway / gaia.weather.read@v1 provenant de iot.modelmarket.dev est admissible pour cet exemple. Une offre indisponible bloque l’invocation.

```sh
npm run discover
```

## 3. Invoquer une seule fois

Cette commande autorise une invocation réelle, plafonnée à $0.01. Sans identifiants, elle sollicite l’essai limité du Hub ; si AIMARKET_API_KEY est défini localement, des crédits peuvent être débités. Un refus de paiement, un délai dépassé ou un reçu invalide arrête l’exécution. Aucun réapprovisionnement ni nouvelle tentative automatique.

```sh
npm run invoke
```

Python vérifie les signatures des reçus localement avec la clé d’origine obtenue par TLS. TypeScript demande la vérification à Hub et exige son verdict sur la clé actuelle. Aucun des deux ne prouve l’exactitude du résultat ni ne fixe indépendamment l’identité. Un succès sauvegarde report.json. attempt.json bloque les répétitions, même après une réponse perdue : clarifiez le premier essai avant de supprimer ce fichier pour autoriser un nouveau débit.

L’archive contient un instantané des sources du générateur ou du SDK et leurs empreintes dans SOURCES.json. Les dépendances sont installées depuis les registres de paquets. Aucune clé privée n’est incluse. Les commandes sont destinées à macOS / Linux ; sous Windows, utilisez WSL. Décompressez le ZIP avant de les exécuter.

https://play.modelmarket.dev/start?role=consumer&stack=typescript&lang=fr
