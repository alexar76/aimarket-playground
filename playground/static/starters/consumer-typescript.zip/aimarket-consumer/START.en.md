# AIMarket / Consumer

Discover a service, invoke with a price ceiling, inspect the receipt. The starter uses the GAIA weather fixture.

## 1. Prepare the client

Install dependencies and run the offline tests. The SDK snapshot is included: Python A2AClient or TypeScript market.run. No account or wallet is needed for discovery.

```sh
cd aimarket-consumer
npm install
npm test
```

## 2. Discover the service

Read-only discovery on modelmarket.dev. Inspect the GAIA weather offer and input.json. Only gaia.gateway / gaia.weather.read@v1 from iot.modelmarket.dev is eligible for this fixture. An unavailable offer stops the invocation.

```sh
npm run discover
```

## 3. Invoke once

This command authorizes one real invocation, capped at $0.01. Without credentials it requests the Hub's limited trial; if AIMARKET_API_KEY is set locally, credits may be charged. Payment refusal, timeout or invalid receipt stops the run. There is no automatic top-up or retry.

```sh
npm run invoke
```

Python verifies receipt signatures locally against the origin key obtained over TLS. TypeScript requests verification from Hub and requires its live-key verdict. Neither proves the result is factually correct or pins identity independently. A successful run saves report.json. attempt.json blocks repeat runs, including after a lost response: reconcile the first attempt before removing it to authorize another charge.

The archive contains a source snapshot from the generators or SDK, with SOURCES.json checksums. Dependencies install from package registries. No private keys are included. Commands use a macOS / Linux shell; on Windows use WSL. Extract the ZIP before running commands.

https://play.modelmarket.dev/start?role=consumer&stack=typescript&lang=en
