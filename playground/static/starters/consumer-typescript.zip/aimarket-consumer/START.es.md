# AIMarket / Consumidor

Descubre un servicio, invócalo con un límite de precio e inspecciona el recibo. El proyecto usa una entrada de ejemplo para el tiempo de GAIA.

## 1. Preparar el cliente

Instala las dependencias y ejecuta las pruebas sin conexión. Incluye una copia del SDK: Python A2AClient o TypeScript market.run. El descubrimiento no requiere cuenta ni billetera.

```sh
cd aimarket-consumer
npm install
npm test
```

## 2. Descubrir el servicio

Descubrimiento de solo lectura en modelmarket.dev. Revisa la oferta del tiempo de GAIA e input.json. Solo gaia.gateway / gaia.weather.read@v1 de iot.modelmarket.dev admite esta entrada. Si la oferta no está disponible, la invocación se detiene.

```sh
npm run discover
```

## 3. Invocar una vez

Este comando autoriza una invocación real con un máximo de $0.01. Sin credenciales solicita la prueba limitada de Hub; si AIMARKET_API_KEY está configurada localmente, puede consumir créditos. El rechazo de pago, un tiempo de espera agotado o un recibo inválido detienen la ejecución. No hay recargas ni reintentos automáticos.

```sh
npm run invoke
```

Python verifica las firmas del recibo localmente con la clave del origen obtenida por TLS. TypeScript solicita la verificación a Hub y exige su veredicto sobre la clave actual. Ninguno demuestra la exactitud del resultado ni fija la identidad de forma independiente. El éxito guarda report.json. attempt.json bloquea repeticiones, incluso tras perder una respuesta: aclara el primer intento antes de eliminarlo para autorizar otro cargo.

El archivo incluye una copia del código del generador o SDK y sumas de comprobación en SOURCES.json. Las dependencias se instalan desde registros de paquetes. No incluye claves privadas. Los comandos son para macOS / Linux; en Windows, usa WSL. Descomprime el ZIP antes de ejecutarlos.

https://play.modelmarket.dev/start?role=consumer&stack=typescript&lang=es
