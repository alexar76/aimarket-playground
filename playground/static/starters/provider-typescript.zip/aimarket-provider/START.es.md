# AIMarket / Proveedor

Tu servicio, un contrato declarado y una firma vinculada a la solicitud. Primero ejecútalo localmente; después comprueba el endpoint público.

## 1. Crear el proveedor

Instala las dependencias y genera tu identidad Ed25519. Mantén .aimarket/provider.key en secreto y haz una copia de seguridad; capability.json contiene solo la clave pública.

```sh
cd aimarket-provider
npm install
npm run configure
python3 -m venv .venv
.venv/bin/python -m pip install -r check-requirements.txt
```

## 2. Verificar localmente

Las pruebas y el perfil de invocación comprueban tu proveedor. El puerto 8080 debe estar libre. check_local.py inicia y detiene el servidor, guarda JSON en report.json y devuelve 0 solo si pasa. Hub no firma el informe.

```sh
npm test
npm run validate
.venv/bin/python check_local.py > report.json
```

## 3. Exponer el endpoint

El comando solo inicia un servidor local. Despliégalo detrás de HTTPS en el puerto 443, conserva la clave privada, configura invoke_url en capability.json y añade control de acceso y límites de solicitudes. Luego importa el manifiesto en la comprobación pública. Nunca subas la clave privada.

```sh
npm start
```

Pasar aimarket-provider-invoke/1 comprueba una invocación y su firma, no todo el protocolo. No publica la capacidad ni prueba recibos Hub, pagos, descubrimiento, federación, frescura o carga. Publicar exige una decisión separada y cumplir las reglas de admisión y garantía del Hub elegido.

El archivo incluye una copia del código del generador o SDK y sumas de comprobación en SOURCES.json. Las dependencias se instalan desde registros de paquetes. No incluye claves privadas. Los comandos son para macOS / Linux; en Windows, usa WSL. Descomprime el ZIP antes de ejecutarlos.

https://play.modelmarket.dev/start?role=provider&stack=typescript&lang=es
